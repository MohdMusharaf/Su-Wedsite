import React from "react";
import './middleposter.css'

function MiddlePoster() {
  return (
<div className="main-div-poster">
<div className="image-items-headphone1">
        <p className="para-featured">Featured Products</p>
        <p className="para-big-sale">Big Sale Up To 40% Off</p>
        <p className="para-items-type">Laptop, Tablet & Accessories</p>
    </div>

    <div className="image-items-wires1">
        <p className="para-featured">Featured Products</p>
        <p className="para-big-sale">Big Sale Up To 40% Off</p>
        <p className="para-items-type">Laptop, Tablet & Accessories</p>
    </div>

    </div>
    
  
)
}

export default MiddlePoster;